# Curso de ReactJS Avanzado

## Ejercicios sesiones 6 y 7

Basándonos en la configuración del service worker y las notificaciones que hemos aprendido:

Crea un formulario en la app de React donde puedas introducir un Título y un Mensaje.

Al enviar este formulario debería activar una ruta en el servidor que hemos creado para que envíe una notificación al cliente con los datos introducidos.
